import 'package:flutter/material.dart';
import 'package:info_med/custom_appbar.dart';

class MedicamentosScreen extends StatelessWidget {
  const MedicamentosScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Tela de Medicamentos',
      theme: ThemeData(
        primarySwatch: Colors.teal,
      ),
      home: _MedicamentosScreen(),
    );
  }
}

class _MedicamentosScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              decoration: InputDecoration(
                labelText: 'Buscar Medicamento',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.search),
              ),
            ),
            SizedBox(height: 20),
            Expanded(
              child: ListView(
                children: [
                  MedicamentoTile(
                    nome: 'Neosaldina',
                    descricao: 'Para dores de cabeça',
                    imagePath: 'assets/imagens/neosaldina.png',
                  ),
                  MedicamentoTile(
                    nome: 'Paracetamol',
                    descricao: 'Para febre e dor',
                    imagePath: 'assets/imagens/paracetamol.png',
                  ),
                  MedicamentoTile(
                    nome: 'Ibuprofeno',
                    descricao: 'Anti-inflamatório e analgésico',
                    imagePath: 'assets/imagens/ibuprofeno.png',
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Continue com o restante do código normalmente...

class MedicamentoTile extends StatelessWidget {
  final String nome;
  final String descricao;
  final String imagePath; // Caminho da miniatura

  MedicamentoTile({
    required this.nome,
    required this.descricao,
    required this.imagePath, // Adicionando o caminho da imagem
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Image.asset(
        imagePath,
        width: 50,
        height: 50,
        fit: BoxFit.cover,
      ),
      title: Text(nome),
      subtitle: Text(descricao),
      onTap: () {
        // Ao clicar, abrirá uma nova tela com mais informações
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => DetalhesMedicamentoScreen(nome: nome),
          ),
        );
      },
    );
  }
}

class DetalhesMedicamentoScreen extends StatelessWidget {
  final String nome;

  DetalhesMedicamentoScreen({required this.nome});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          nome,
          style: TextStyle(
            color: Colors.white, // Define a cor do texto do título do AppBar
          ),
        ),
        backgroundColor: Colors.blue,
        iconTheme: IconThemeData(
            color: Colors.white), // Altera a cor do ícone de voltar
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            Text(
              nome,
              style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            Divider(),
            ListTile(
              leading: Icon(Icons.local_pharmacy, color: Colors.blueAccent),
              title: Text(
                'Componentes',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              subtitle: Text(
                'Dipirona sódica + mucato de isometepteno + cafeína',
                style: TextStyle(fontSize: 16),
              ),
            ),
            Divider(),
            ListTile(
              leading: Icon(Icons.healing, color: Colors.blueAccent),
              title: Text(
                'Indicações',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              subtitle: Text(
                'Condições Tratadas: Cefaleia (dor de cabeça). Uso Primário: Alívio rápido de dores de cabeça e enxaquecas.',
                style: TextStyle(fontSize: 16),
              ),
            ),
            Divider(),
            ListTile(
              leading: Icon(Icons.access_time, color: Colors.blueAccent),
              title: Text(
                'Dosagem',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              subtitle: Text(
                'Dose indicada: 1/2 comprimido, a cada 6 horas. Frequência: Não exceder 8 comprimidos em 24 horas.',
                style: TextStyle(fontSize: 16),
              ),
            ),
            Divider(),
            ListTile(
              leading: Icon(Icons.attach_money, color: Colors.blueAccent),
              title: Text(
                'Preço Médio',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              subtitle: Text(
                'R\$ 10 - R\$ 20',
                style: TextStyle(fontSize: 16),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
