import 'package:flutter/material.dart';
import 'package:info_med/custom_appbar.dart';

class SintomasScreen extends StatelessWidget {
  const SintomasScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:const CustomAppBar(),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            const TextField(
              decoration: InputDecoration(
                labelText: 'Buscar Sintoma',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.search),
              ),
            ),
            SizedBox(height: 20),
            Expanded(
              child: ListView(
                children: [
                  Text('Dor de cabeça'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}