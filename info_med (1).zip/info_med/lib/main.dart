import 'package:flutter/material.dart';
import 'tela_cadastro.dart'; // Importa o arquivo com a tela de cadastro

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Tela de Cadastro',
      theme: ThemeData(
        primarySwatch: Colors.teal,
      ),
      home: CadastroScreen(), // Define a tela de cadastro como inicial
    );
  }
}
