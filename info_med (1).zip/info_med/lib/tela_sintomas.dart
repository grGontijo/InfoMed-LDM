import 'package:flutter/material.dart';

class SintomasScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Tela de Sintomas',
      theme: ThemeData(
        primarySwatch: Colors.teal,
      ),
      home: _SintomasScreen(),
    );
  }
}

class _SintomasScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(100.0), // Aumenta a altura do AppBar
        child: AppBar(
          title: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset('assets/imagens/logo.png',
                  height: 230), // Ajuste o tamanho da logo se necessário
              SizedBox(width: 100),
            ],
          ),
          backgroundColor: Color(0xFF1630C1), // Cor azul do AppBar
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              decoration: InputDecoration(
                labelText: 'Buscar Sintoma',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.search),
              ),
            ),
            SizedBox(height: 20),
            Expanded(
              child: ListView(
                children: [
                  Text('Dor de cabeça'),
                ],
              ),
            ),
          ],
        ),
      ),

    );
  }
}
