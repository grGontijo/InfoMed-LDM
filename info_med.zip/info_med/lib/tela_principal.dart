import 'package:flutter/material.dart';
import 'package:info_med/tela_medicamentos.dart';
import 'package:info_med/tela_sintomas.dart';
import 'package:info_med/tela_perfil.dart'; // Importação da tela de perfil

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _indiceAtual = 0;
  final List<Widget> _telas = [
    MedicamentosScreen(),
    SintomasScreen(),
    PerfilScreen() // Substituindo SobreAppScreen pela tela de perfil
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _telas[_indiceAtual],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _indiceAtual,
        onTap: onTabTapped,
        backgroundColor: Color(0xFF1630C1), // Cor de fundo azul
        selectedItemColor: Colors.white, // Cor do ícone selecionado
        unselectedItemColor: Colors.white70, // Cor dos ícones não selecionados
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.local_hospital),
            label: 'Medicamentos',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.healing),
            label: 'Sintomas',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Perfil', // Alterado de "Sobre" para "Perfil"
          ),
        ],
      ),
    );
  }

  void onTabTapped(int index) {
    setState(() {
      _indiceAtual = index;
    });
  }
}
