import 'package:flutter/material.dart';
import 'package:info_med/tela_sobreapp.dart'; // Importando a tela "Sobre App"

class PerfilScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(120), // Altura reduzida para o AppBar
        child: AppBar(
          backgroundColor: Color(0xFF1630C1),
          flexibleSpace: Column(
            mainAxisAlignment:
                MainAxisAlignment.center, // Alinhamento centralizado
            children: [
              Image.asset(
                'assets/imagens/logo.png', // Caminho para a logo
                height: 80, // Altura da logo reduzida
                fit: BoxFit.contain,
              ),
              SizedBox(height: 8), // Espaço entre a logo e o título
            ],
          ),
          iconTheme:
              IconThemeData(color: Colors.white), // Cor do ícone de voltar
        ),
      ),
      body: SingleChildScrollView(
        // Adicionando o SingleChildScrollView
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            // Foto do usuário
            CircleAvatar(
              radius: 60,
              backgroundImage: AssetImage(
                  'assets/imagens/user_profile.png'), // Caminho para a imagem do perfil
              backgroundColor: Colors.grey[300],
            ),
            SizedBox(height: 20),

            // Nome do usuário
            Text(
              'Nome do Usuário',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.teal,
              ),
            ),
            SizedBox(height: 10),

            // Email do usuário
            Text(
              'email@exemplo.com',
              style: TextStyle(
                fontSize: 16,
                color: Colors.grey[700],
              ),
            ),
            SizedBox(height: 20),

            // Informações adicionais
            Divider(),
            ListTile(
              leading: Icon(Icons.phone, color: Colors.teal),
              title: Text('Telefone'),
              subtitle: Text('(31) 1234-5678'),
            ),
            Divider(),
            ListTile(
              leading: Icon(Icons.location_on, color: Colors.teal),
              title: Text('Endereço'),
              subtitle: Text('Rua Exemplo, 123 - Belo Horizonte, MG'),
            ),
            Divider(),

            // Botão para editar perfil
            ElevatedButton(
              onPressed: () {
                // Navegar para a tela de edição de perfil (caso implementada)
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.teal, // Cor do botão
                padding: EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
              ),
              child: Text(
                'Editar Perfil',
                style: TextStyle(fontSize: 18, color: Colors.white),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
